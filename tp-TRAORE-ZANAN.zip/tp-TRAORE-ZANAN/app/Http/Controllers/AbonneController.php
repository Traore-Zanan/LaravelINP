<?php

namespace App\Http\Controllers;

use App\Models\Abonne;
use App\Models\Compte;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AbonneController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        return response()->json(Abonne::all());
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $validate = Validator::make($request->all(), [
            "nom" => "required",
            "prenom" => "required",
            "email" => "required|email|unique:abonnes,email",
            "contact" => "required|unique:abonnes,contact",
            
        ]);

        if ($validate->fails()) {
            return response()->json([
                "error" => true,
                "message" => $validate->errors()->first()
            ]);
        }

        $abonne = Abonne::create([
            "nom" => $request->get('nom'),
            "prenom" => $request->get('prenom'),
            "email" => $request->get('email'),
            "contact" => $request->get('contact'),
            //"active" => $request->get('active')
        ]);

        return response()->json([
            'error' => false,
            'message' => "Operation effectue avec succes",
            'data' => $abonne
        ]);
   

    }

    /**
     * Display the specified resource.
     */
    public function show(String $id)
    {
        //
        $abonne = Abonne::find($id);
        if ($abonne == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucune abonne trouvée avec cet id : " . $id
            ]);
        }

        $abonne["comptes"] =  $abonne->comptes;
        return response()->json([
            'error' => false,
            'message' => "Operation effectue avec succes",
            'data' => $abonne,
            
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, String $id)
    {
        //
        $abonne = Abonne::find($id);
        if ($abonne == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucune abonne trouvée avec cet id : " . $id
            ]);
        }

        $validate = Validator::make($request->all(), [
            "nom" => "required",
            "prenom" => "required",
            "email" => "required|email|unique:abonne,email," . $abonne->id,
            "contact" => "required|unique:abonne,contact," . $abonne->id,
            "active" => "required"
        ]);

        if ($validate->fails()) {
            return response()->json([
                "error" => true,
                "message" => $validate->errors()->first()
            ]);
        }

        $abonne->update([
            "nom" => $request->get('nom'),
            "prenom" => $request->get('prenom'),
            "email" => $request->get('email'),
            "contact" => $request->get('contact'),
            "active" => $request->get('active')
        ]);

        return response()->json([
            'error' => false,
            'message' => "Operation effectue avec succes",
            'data' => $abonne
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(String $id)
    {
        //
        $abonne = Abonne::find($id);
        if ($abonne == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucune abonne trouvée avec cet id : " . $id
            ]);   
        }

        $abonne->delete();

        return response()->json([
            'error' => false,
            'message' => "Operation effectue avec succes, abonne supprimé",
        ]);
    }




    public function abonneCompte(){
        $clientsWithAccounts = Abonne::with('compte')->get();
        return response()->json($clientsWithAccounts);

    }


    public function detAboCompte($id)
    {
        //
        $abonne = Abonne::find($id);
        if ($abonne == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucune abonne trouvée avec cet id : " . $id
            ]);
        }

        $abonne["comptes"] =  $abonne->comptes;
        $compt = Compte::where('abonne_id','=', $id)->get();
        return response()->json([
            'error' => false,
            'message' => "Operation effectue avec succes",
            'data' => $abonne,
            'compte' => $compt
        ]);
    }



    public function abonneStat($id)
{
    $abonne = Abonne::find($id);
    if ($abonne == null) {
        return response()->json([
            "error" => true,
            "message" => "Aucun abonné trouvé avec cet ID : " . $id
        ]);
    }

    $totalComptes = $abonne->compte->count();
    $totalActiveComptes = $abonne->compte->where('active', true)->count();
    $totalInactiveComptes = $abonne->compte->where('active', false)->count();

    return response()->json([
        'error' => false,
        'message' => "Opération effectuée avec succès",
        'total_comptes' => $totalComptes,
        'total_comptes_actifs' => $totalActiveComptes,
        'total_comptes_inactifs' => $totalInactiveComptes
    ]);
}


public function glStat()
{
    $totalClients = Abonne::count();
    $totalAccounts = Compte::count();
    $totalActiveAccounts = Compte::where('active', true)->count();
    $totalInactiveAccounts = Compte::where('active', false)->count();

    return response()->json([
        'total_clients' => $totalClients,
        'total_accounts' => $totalAccounts,
        'total_active_accounts' => $totalActiveAccounts,
        'total_inactive_accounts' => $totalInactiveAccounts
    ]);
}


}
