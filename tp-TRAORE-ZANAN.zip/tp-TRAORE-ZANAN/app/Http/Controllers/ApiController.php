<?php

namespace App\Http\Controllers;
use App\Models\Abonne;
use App\Models\Compte;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
class IntegrationApiController extends Controller
{
    //


    public function integration(){

        $response = Http::get("https://rawcdn.githack.com/kamikazechaser/administrative-divisions-db/master/api/CI.json" );
        
        
        $region=json_decode($response->body());

        return response()->json([
            "langue"=> "Français",
           "genre"=> "Masculin",
          "religion"=> "Chretien",
          "pays"=>"Côte d'Ivoire",
        "indicatif"=> "CI",
         "internet"=> true,
      "regions"=> $region]);


    }



    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            $token = Auth::user()->createToken('auth-token')->plainTextToken;
            return response()->json(['token' => $token]);
        }

        return response()->json(['message' => 'Unauthorized'], 401);
    }


    public function liaison(Request $request){

        $validate = Validator::make($request->all(), [
            "abonneId" => "required",
            "compteId" => "required",
        ]);

        if ($validate->fails()) {
            return response()->json([
                "error" => true,
                "message" => $validate->errors()->first()
            ]);
        }

    $abonneId=$request->post('abonneId');
    $compteId=$request->post('compteId');
        
        $compte = Compte::find($compteId);
        if ($compte == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucun compte trouvé avec cet id : " . $compteId
            ]);
        }
       
        $compte->update([
            "abonne_id" =>$abonneId,
        ]);

        return response()->json([
            'error' => false,
            'message' => "Abonne modifier avec succes",
        ]);
    }


}
