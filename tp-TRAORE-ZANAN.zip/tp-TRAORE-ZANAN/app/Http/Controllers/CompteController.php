<?php

namespace App\Http\Controllers;

use App\Models\Abonne;
use App\Models\Compte;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CompteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        return response()->json(Compte::all());
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $validate = Validator::make($request->all(), [
            "libelle" => "required",
            "description" => "required",
            "agence" => "required",
            "banque" => "required",
            "numero" => "required|unique:comptes,numero",
            "rib" => "required|unique:comptes,rib",
            "montant" => "required",
            "domiciliation" => "required",


        ]);

        if ($validate->fails()) {
            return response()->json([
                "error" => true,
                "message" => $validate->errors()->first()
            ]);
        }

        $compte = Compte::create([
            "libelle" => $request->get('libelle'),
            "description" => $request->get('description'),
            "agence" => $request->get('agence'),
            "banque" => $request->get('banque'),
            "numero" => $request->get('numero'),
            "rib" => $request->get('rib'),
            "montant" => $request->get('montant'),
            "domiciliation" => $request->get('domiciliation')
            

        ]);
 return response()->json([
            'error' => false,
            'message' => "Operation effectue avec succes",
            'data' => $compte
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(String $id)
    {
        //
        $compte = Compte::find($id);
        if ($compte == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucune compte trouvée avec cet id : " . $id
            ]);
        }

        $compte["abonnes"] =  $compte->abonnes;
        return response()->json([
            'error' => false,
            'message' => "Operation effectue avec succes",
            'data' => $compte
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, String $id)
    {
        //
        $compte = Compte::find($id);
        if ($compte == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucune compte trouvée avec cet id : " . $id
            ]);
        }

        $validate = Validator::make($request->all(), [
            "libelle" => "required",
            "description" => "required",
            "agence" => "required",
            "banque" => "required",
            "numero" => "required|unique:comptes,numero," . $compte->id,
            "rib" => "required|unique:comptes,rib," . $compte->id,
            "montant" => "required",
            "domiciliation" => "required"
        ]);

        if ($validate->fails()) {
            return response()->json([
                "error" => true,
                "message" => $validate->errors()->first()
            ]);
        }

        $compte->update([
            "libelle" => $request->get('libelle'),
            "description" => $request->get('description'),
            "agence" => $request->get('agence'),
            "banque" => $request->get('banque'),
            "numero" => $request->get('numero'),
            "rib" => $request->get('rib'),
            "montant" => $request->get('montant'),
            "domiciliation" => $request->get('domiciliation')
            
        ]);

        return response()->json([
            'error' => false,
            'message' => "Operation effectue avec succes",
            'data' => $compte
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        $compte = Compte::find($id);
        if ($compte == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucune compte trouvé avec cet id : " . $id
            ]);
        }

        $compte->delete();

        return response()->json([
            'error' => false,
            'message' => "Operation effectuée avec succes, compte supprimé",
        ]);
    }


    public function statistiques_abonnee($id){
        $abonne = Abonne::find($id);
        if ($abonne == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucun abonné trouvé avec cet id : " . $id
            ]);
        }


        $stats = Compte::where('abonne_id', $id)->select(
            DB::raw('COUNT(*) as count'),
            DB::raw('SUM(montant) as total'),
            DB::raw('MIN(montant) as min'),
            DB::raw('MAX(montant) as max'),
            DB::raw('AVG(montant) as average')
        )->first();

        return response()->json([
            "error" => false,
            "data" => $stats
        ]);

    }public function getCompteById($iban)
    {
        $compte = Compte::find($iban);
    
        if ($compte == null) {
            return response()->json([
                "error" => true,
                "message" => "Aucun compte trouvé avec cet ID : " . $id
            ]);
        }
    
        $compteDetails = [
            'banque' => $compte->banque,
            'agence' => $compte->agence,
            'numero' => $compte->numero,
            'rib' => $compte->rib
        ];
    
        return response()->json([
            'error' => false,
            'message' => "Détails du compte",
            'data' => $compteDetails
        ]);
    }

}
