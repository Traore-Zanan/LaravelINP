<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AbonneController;
use App\Http\Controllers\CompteController;
use App\Http\Models\apiResource;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::prefix('v1')->group(function () {
    Route::apiResources([
        'abonne' => AbonneController::class,
        'compte' => CompteController::class
    ]);

    
});
Route::prefix('abonne')->group(function () {

    Route::get('/compte', [AbonneController::class, 'abonneCompte']);

    Route::get('/{id}/compte', [AbonneController::class, 'detAboCompte']);
    
});


    
Route::get('/stats', [AbonneController::class, 'glStat']);

Route::get('/comptes/{id}', [CompteController::class, 'getCompteById']);


Route::prefix('stats')->group(function () {  

    Route::get('/abonnes/{id}', [AbonneController::class, 'abonneStat']);
    Route::get('/abonne/{id}', [CompteController::class, 'statistiques_abonnee']);

});
